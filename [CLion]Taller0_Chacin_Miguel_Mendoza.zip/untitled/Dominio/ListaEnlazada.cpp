//
// Created by elmig on 07/09/2025.
//

#include "ListaEnlazada.h"

#include <iostream>

#include "Musica.h"
#include "NodoSimple.h"

using namespace std;

ListaEnlazada::ListaEnlazada(): cabecera(nullptr), tamano(0)
{}

ListaEnlazada::~ListaEnlazada() {
    clear();
}
//Insertar en inicio
void ListaEnlazada::insertarInicio(Musica *musicaNueva) {
    NodoSimple* nuevoNodo = new NodoSimple(musicaNueva);
    nuevoNodo->setSiguiente(cabecera);
    cabecera = nuevoNodo;
    tamano++;
}

void ListaEnlazada::insertarFin(Musica *musicaNueva) {
    NodoSimple* nuevoNodo = new NodoSimple(musicaNueva);
        if (!cabecera) {
            cabecera = nuevoNodo;
        }else {
NodoSimple* actual = cabecera;
            while (actual->getSiguiente() != nullptr) {

                actual = actual->getSiguiente();

            }//Termina el while
            actual->setSiguiente(nuevoNodo);

        }//Termina el else
    tamano++;

}//Termina el metodo


//EliminarPorNombre

bool ListaEnlazada::eliminarPorNombre(const string &nombre) {
NodoSimple* actual = cabecera;
    NodoSimple* anterior = nullptr;

    while (actual != nullptr) {
Musica* musica = actual->getDato();
        if (musica&& musica->getNombre() == nombre) {
if (anterior == nullptr) {
    cabecera = actual->getSiguiente();
}//Termina el if dentro del if
            else {

  anterior->setSiguiente(actual->getSiguiente());
}//Termina el else

            delete actual;
            tamano--;
            return true;




        }//Termina el if
anterior = actual;
        actual = actual->getSiguiente();


    }//Termina el While

    return false;


}//Termina el metodo eliminarporNombre

//Metodo buscarPorNombre
Musica* ListaEnlazada::buscarPorNombre(const string& nombre) const {
    NodoSimple* actual = cabecera;
    while (actual != nullptr) {
        Musica* musica = actual->getDato();
        if (musica && musica->getNombre() == nombre) {
            return musica;
        }//Termina el if
        actual = actual->getSiguiente();
    }//Termina el while
    return nullptr;
}//Termina el metodo buscarPorNombre


//Metodo Listar

void ListaEnlazada::listar() const {
    NodoSimple* actual = cabecera;
    int indice = 1;
    while (actual != nullptr) {
        Musica* musica = actual->getDato();
        if (musica) {
            cout << indice << ". " << musica->toString() << "\n";
        } else {
            cout << indice << ". (nodo vacío)\n";
        }
        actual = actual->getSiguiente();
        indice++;
    }//Termina el while
    if (indice == 1) {
        cout << "(lista vacía)\n";
    }
}//Termina el metodo Listar



//metodo clear

void ListaEnlazada::clear() {
    NodoSimple* actual = cabecera;
    while(actual != nullptr) {
        NodoSimple* siguienteNodo = actual->getSiguiente();
        delete actual;
        actual = siguienteNodo;
    }//Termina el while
    cabecera = nullptr;
    tamano = 0;

}//Termina el metodo clear





