//
// Created by elmig on 07/09/2025.
//

#ifndef UNTITLED_VISTA_H
#define UNTITLED_VISTA_H
#include <string>
#include "../Sistema/Sistema.h"

using namespace std;

class Vista {

private:
    Sistema* sistema;  // referencia al motor del sistema

public:
    explicit Vista(Sistema* sistema);

    void mostrarMenuPrincipal();
    void mostrarMenuUsuario();
    void mostrarMenuBiblioteca();
    void mostrarMenuPlaylists();
};



#endif //UNTITLED_VISTA_H