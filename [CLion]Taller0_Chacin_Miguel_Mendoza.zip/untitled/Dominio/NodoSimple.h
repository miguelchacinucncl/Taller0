//
// Created by elmig on 07/09/2025.
//

#ifndef UNTITLED_NODOSIMPLE_H
#define UNTITLED_NODOSIMPLE_H
#pragma once
#include "Musica.h"

class NodoSimple {

private:

    Musica* dato;
    NodoSimple* siguiente;

public:
    explicit NodoSimple(Musica* dato);

    Musica* getDato() const;
    NodoSimple* getSiguiente() const;
    void setSiguiente(NodoSimple* siguiente);

};


#endif //UNTITLED_NODOSIMPLE_H