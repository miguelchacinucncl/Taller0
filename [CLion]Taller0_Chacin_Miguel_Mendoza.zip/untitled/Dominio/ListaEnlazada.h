//
// Created by elmig on 07/09/2025.
//

#ifndef UNTITLED_LISTAENLAZADA_H
#define UNTITLED_LISTAENLAZADA_H

#include <string>
#include "NodoSimple.h"
#include "Musica.h"
using namespace std;

class ListaEnlazada {

    private:

    NodoSimple* cabecera;
    int tamano;

public:

    //constructores
    ListaEnlazada();
    ~ListaEnlazada();


    //operaciones
    void insertarInicio(Musica* musicaNueva);
    void insertarFin(Musica* musicaNueva);

    bool eliminarPorNombre(const string& nombre);
    Musica* buscarPorNombre(const string& nombre) const;

void listar() const;


    //utilidades

    int getTamano() const {
        return tamano;
    };

    bool estaVacia() const {
        return cabecera == nullptr;
    }

    void clear();




};


#endif //UNTITLED_LISTAENLAZADA_H