//
// Created by elmig on 07/09/2025.
//

#include "Musica.h"

#include <sstream>
#include <utility>

using namespace std;

Musica::Musica(string nombre, string album, string artista, int duracionSeg)
    : nombre(std::move(nombre)), album(std::move(album)), artista(std::move(artista)), duracionSeg(duracionSeg) {}

string Musica::getNombre() const {
    return nombre;
}

string Musica::getAlbum() const {
    return album;
}

string Musica::getArtista() const {
    return artista;
}

int Musica::getDuracionSeg() const {
    return duracionSeg;
}

void Musica::setNombre(string nuevoNombre) {
    nombre = std::move(nuevoNombre);
}

void Musica::setAlbum(string nuevoAlbum) {
    album = std::move(nuevoAlbum);
}

void Musica::setArtista(string nuevoArtista) {
    artista = std::move(nuevoArtista);
}

void Musica::setDuracionSeg(int nuevaDuracion) {
    duracionSeg = nuevaDuracion;
}

string Musica::toString() const {
    return nombre + string(" - ") + artista + string(" (") + album + string(", ") + to_string(duracionSeg) + string("s)");
}
