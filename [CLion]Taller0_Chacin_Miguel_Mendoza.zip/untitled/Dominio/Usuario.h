#pragma once
#include <string>
#include <stdexcept>
#include <vector>
#include "Playlist.h"

using std::string;
using std::vector;

class Usuario {
private:

    string nombreDeUsuario;
    string correo;
    string contrasenia;
    vector<Playlist> playlists;   // el maximo son 3 playlist por usuario

public:
    Usuario() = default;

    // Constructor
    Usuario(string nombre, string correoUsuario, string contraseniaUsuario)
        : nombreDeUsuario(nombre), correo(correoUsuario), contrasenia(contraseniaUsuario) {
        if (nombreDeUsuario.empty()) throw std::invalid_argument("nombre vacío");
        if (correo.empty())          throw std::invalid_argument("correo vacío");
        if (contrasenia.empty())     throw std::invalid_argument("contraseña vacía");
    }

    // Getters
    string getNombreDeUsuario() const { return nombreDeUsuario; }
    string getCorreo()          const { return correo; }
    string getContrasenia()     const { return contrasenia; }

    // Setters
    void setNombreDeUsuario(string nuevoNombre) {
        if (nuevoNombre.empty()) throw std::invalid_argument("nombre vacío");
        nombreDeUsuario = nuevoNombre;
    }
    void setCorreo(string nuevoCorreo) {
        if (nuevoCorreo.empty()) throw std::invalid_argument("correo vacío");
        correo = nuevoCorreo;
    }
    void setContrasenia(string nuevaContrasenia) {
        if (nuevaContrasenia.empty()) throw std::invalid_argument("contraseña vacía");
        contrasenia = nuevaContrasenia;
    }

    //  playlists
    bool agregarPlaylist(string nombre);
    bool eliminarPlaylist(string nombre);
    Playlist* buscarPlaylist(string nombre);
    vector<Playlist> getPlaylists() const { return playlists; }
    int getCantidadPlaylists() const { return (int)playlists.size(); }
};
