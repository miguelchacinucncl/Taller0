//
// Created by elmig on 07/09/2025.
//
#ifndef UNTITLED_PLAYLIST_H
#define UNTITLED_PLAYLIST_H

#include <string>
#include "Musica.h"
#include "ListaEnlazada.h"

using namespace std;

class Playlist {
private:
    string nombre;
    ListaEnlazada canciones; // guarda punteros a Musica que estan en la Biblioteca

public:
    // Constructor
    explicit Playlist(string nombre);

    // Getters/Setters
    string getNombre() const;
    void setNombre(string nuevoNombre);

    // Operaciones sobre canciones
    bool agregarCancion(Musica* cancion);
    bool eliminarCancion(string nombreCancion);
    void listarCanciones() const;

    // Utilidades
    int getCantidad() const;     // cantidad de canciones en la lista
    bool estaVacia() const;
};

#endif //UNTITLED_PLAYLIST_H
